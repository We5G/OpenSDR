**AD9739A-FMC-EBZ**

The following drivers are required for building the **AD9739A-FMC-EBZ** no-OS project:
 - AD9739A-FMC-EBZ Main Driver	-	[./] (./)
 - Xilinx Platform Drivers		-	[../common_drivers/xilinx_platform_drivers] (../common_drivers/xilinx_platform_drivers)
 - AD9739A Driver				-	[../drivers/ad9739a] (../drivers/ad9739a)
 - ADF4350 Driver				-	[../drivers/adf4350] (../drivers/adf4350)
 - DAC Core Driver				-	[../common_drivers/dac_core] (../common_drivers/dac_core)
