**AD9361** Bare Metal Quick Start Guide: [https://wiki.analog.com/resources/eval/user-guides/ad-fmcomms2-ebz/software/baremetal] (https://wiki.analog.com/resources/eval/user-guides/ad-fmcomms2-ebz/software/baremetal)

The following drivers are required for building the **FMCOMMS2/3/4/5** no-OS project:
 - AD9361 Main Driver			-	[./sw/] (./sw/)
 - Xilinx Platform Drivers		-	[./sw/platform_xilinx/] (./sw/platform_xilinx/)
