The AD9250-EBZ reference design requires the following driver:
 - AD9250 -> https://github.com/analogdevicesinc/no-OS/tree/master/drivers/AD9250