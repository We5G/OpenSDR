The AD6673-EBZ reference design requires the following driver:
 - AD6673 -> https://github.com/analogdevicesinc/no-OS/tree/master/drivers/AD6673